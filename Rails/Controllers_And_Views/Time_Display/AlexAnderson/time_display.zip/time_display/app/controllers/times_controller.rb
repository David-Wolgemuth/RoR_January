class TimesController < ApplicationController
  def main
    session[:time] = Time.now.strftime("%b %d, %Y %H:%M:%p %Z")
    render 'times/main'
  end
end
